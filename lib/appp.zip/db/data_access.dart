import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class Mydatabase {
  static final Mydatabase _instance = Mydatabase._internal();
  factory Mydatabase() => _instance;
  static Database? _database;

  Mydatabase._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'matrimony.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        mobile TEXT,
        address TEXT,
        dob TEXT,
        age INTEGER,
        gender TEXT,
        age INTEGER,
        city TEXT,
        profession TEXT,
        cast TEXT,
        country TEXT,
        marital_status TEXT,
        salary_range TEXT,
        isfavorite INTEGER DEFAULT 0
      )
    ''');
  }


  Future<List<Map<String, dynamic>>> getUsers() async {
    try {
      Database db = await database;
      final List<Map<String, dynamic>> users = await db.query('users');

      if (users.isNotEmpty) {
        print("Users loaded: ${users.length} records");
        return users;
      } else {
        print("No users found in the database.");
        return [];
      }
    } catch (e) {
      print("Database Error in getUsers(): $e");
      return [];
    }
  }


  Future<int> insertUser(Map<String, dynamic> userData) async {
    try {
      Database db = await database;
      int id = await db.insert('users', userData);
      return id;
    } catch (e) {
      print("Error inserting user: $e");
      return -1;
    }
  }

  Future<Map<String, dynamic>?> getUserById(int id) async {
    Database db = await database;
    List<Map<String, dynamic>> result = await db.query(
      'users',
      where: 'id = ?',
      whereArgs: [id],
    );
    return result.isNotEmpty ? result.first : null;
  }

  Future<int> deleteUser(int id) async {
    try {
      Database db = await database;
      return await db.delete('users', where: 'id = ?', whereArgs: [id]);
    } catch (e) {
      print("Error deleting user: $e");
      return -1;
    }
  }

  Future<int> updateUser(int id, Map<String, dynamic> userData) async {
    try {
      Database db = await database;
      return await db.update(
        'users',
        userData,
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      print("Error updating user: $e");
      return -1; // Indicate failure
    }
  }


  Future<int> updateUserFavorite(int id, int isFavorite) async {
    try {
      Database db = await database;
      return await db.update(
        'users',
        {'isfavorite': isFavorite},
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      print("Error updating favorite status: $e");
      return -1; // Indicate failure
    }
  }
}
